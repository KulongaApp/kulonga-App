import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, SafeAreaView, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Controller, useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Ionicons } from '@expo/vector-icons';
import { Input, Button } from '../../components';
import { supabase } from '../../services';
import { activarConviteProfessor } from '../../services/professores';

const schema = z.object({
  convite: z.string().trim().regex(/^[a-f0-9]{32}$/, 'Introduz o código de 32 caracteres recebido da escola.'),
  nome: z.string().trim().min(3, 'Nome deve ter pelo menos 3 caracteres'),
  email: z.string().trim().email('Insere um email válido'),
  senha: z.string().min(8, 'A senha deve ter pelo menos 8 caracteres'),
  confirmarSenha: z.string().min(8, 'Confirma a senha'),
}).refine((data) => data.senha === data.confirmarSenha, { message: 'As senhas não coincidem', path: ['confirmarSenha'] });
type FormData = z.infer<typeof schema>;

export default function ActivarConviteProfessor() {
  const router = useRouter();
  const params = useLocalSearchParams<{ convite?: string }>();
  const [loading, setLoading] = useState(false);
  const conviteInicial = typeof params.convite === 'string' ? params.convite.toLowerCase() : '';
  const { control, handleSubmit } = useForm<FormData>({ resolver: zodResolver(schema), defaultValues: { convite: conviteInicial, nome: '', email: '', senha: '', confirmarSenha: '' } });
  async function onSubmit(data: FormData) {
    setLoading(true);
    try {
      await AsyncStorage.setItem('kulonga_convite_professor_pendente', data.convite.toLowerCase());
      const { data: authData, error } = await supabase.auth.signUp({ email: data.email.toLowerCase(), password: data.senha, options: { data: { papeis: ['professor'], nome: data.nome } } });
      if (error) throw error;
      if (!authData.user) throw new Error('Não foi possível criar a conta.');
      if (authData.session) {
        await activarConviteProfessor(data.convite);
        await AsyncStorage.removeItem('kulonga_convite_professor_pendente');
        Alert.alert('Conta criada', 'A tua conta foi associada à escola. Já podes entrar.', [{ text: 'Ir para login', onPress: () => router.replace('/(auth)/login-professor' as any) }]);
      } else {
        Alert.alert('Confirma o email', 'Confirma primeiro o email recebido. Depois entra no login de professor para concluir a activação do convite.', [{ text: 'Ir para login', onPress: () => router.replace('/(auth)/login-professor' as any) }]);
      }
    } catch (e: any) {
      await AsyncStorage.removeItem('kulonga_convite_professor_pendente');
      Alert.alert('Não foi possível criar a conta', e?.message ?? 'Verifica o convite e tenta novamente.');
    } finally { setLoading(false); }
  }
  return <SafeAreaView style={s.safe}><KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}><ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled"><TouchableOpacity onPress={() => router.back()}><Text style={s.back}>Voltar</Text></TouchableOpacity><Text style={s.logo}>KULONGA</Text><Ionicons name="key-outline" size={42} color="#123C69" /><Text style={s.title}>Activar convite de professor</Text><Text style={s.subtitle}>Este acesso só funciona com um link ou código emitido pela secretaria. O convite é único e expira em 24 horas.</Text><View style={s.form}><Controller control={control} name="convite" render={({ field, fieldState }) => <Input label="Código do convite" placeholder="Código de 32 caracteres" valor={field.value} onMudar={field.onChange} icone="key-outline" erro={fieldState.error?.message} />} /><Controller control={control} name="nome" render={({ field, fieldState }) => <Input label="Nome indicado pela secretaria" placeholder="Nome conforme o convite" valor={field.value} onMudar={field.onChange} icone="person-outline" erro={fieldState.error?.message} />} /><Controller control={control} name="email" render={({ field, fieldState }) => <Input label="Email do convite" placeholder="professor@escola.ao" valor={field.value} onMudar={field.onChange} icone="mail-outline" teclado="email-address" erro={fieldState.error?.message} />} /><Controller control={control} name="senha" render={({ field, fieldState }) => <Input label="Criar senha" placeholder="Mínimo 8 caracteres" valor={field.value} onMudar={field.onChange} seguro icone="lock-closed-outline" erro={fieldState.error?.message} />} /><Controller control={control} name="confirmarSenha" render={({ field, fieldState }) => <Input label="Confirmar senha" placeholder="Repete a senha" valor={field.value} onMudar={field.onChange} seguro icone="lock-closed-outline" erro={fieldState.error?.message} />} /><Button titulo="Activar conta" onPress={handleSubmit(onSubmit) as any} variante="primario" tamanho="grande" carregando={loading} /></View><View style={s.footer}><Text style={s.muted}>Já tens conta?</Text><TouchableOpacity onPress={() => router.push('/(auth)/login-professor' as any)}><Text style={s.link}>Entrar como professor</Text></TouchableOpacity></View></ScrollView></KeyboardAvoidingView></SafeAreaView>;
}
const s = StyleSheet.create({ safe: { flex: 1, backgroundColor: '#fff' }, scroll: { padding: 20, paddingBottom: 50 }, back: { color: '#55667A', marginBottom: 12 }, logo: { color: '#8F5F00', fontWeight: '800', fontSize: 22 }, title: { color: '#0B2A4A', fontSize: 23, fontWeight: '900', marginTop: 12 }, subtitle: { color: '#55667A', lineHeight: 21, marginTop: 8 }, form: { marginTop: 22 }, footer: { alignItems: 'center', marginTop: 24 }, muted: { color: '#55667A' }, link: { color: '#123C69', fontWeight: '800', marginTop: 5 } });
